
print "I'm now cached as a subroutine!\n";
