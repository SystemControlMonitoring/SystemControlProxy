print "I shan't be printed.";
sub showtime {
    print time;
}
