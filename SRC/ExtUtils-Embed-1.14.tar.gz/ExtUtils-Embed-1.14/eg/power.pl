sub expo {
    my ($a, $b) = @_;
    return $a ** $b;
}
