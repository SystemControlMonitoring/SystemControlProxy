package FCGI;

$VERSION = '0.74';
